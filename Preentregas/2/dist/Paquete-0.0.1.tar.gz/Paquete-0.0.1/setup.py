from setuptools import setup

setup(
    author="Joaquin Ibarra",
    author_email="juacoibarra02@gmail.com",
    description="Paquete de la preentrega 2",
    version="0.0.1",
    name="Paquete",
    packages=["Paquete"]
)